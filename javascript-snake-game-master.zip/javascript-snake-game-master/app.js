'use strict';

// Об'явлення глобальних змінних для елементів гри та параметрів гри
var gameStart = {},  // Початок гри (кнопка "Start")
  gameSpeed = {},    // Швидкість гри (поле вибору швидкості)
  gameArea = {},     // Область гри (канва)
  gameAreaContext = {}, // Контекст для малювання на канві
  snake = [],        // Масив для зберігання координат змії
  gameAreaWidth = 0, // Ширина області гри
  gameAreaHeight = 0, // Висота області гри
  cellSize = 0,     // Розмір клітинки на канві
  playerScore = 0,   // Рахунок гравця
  snakeFood = {},    // Координати їжі для змії
  snakeDirection = '', // Напрямок руху змії
  speedSize = 0,     // Розмір швидкості (коефіцієнт)
  timer = {};        // Таймер для оновлення гри

// Ініціалізація елементів гри
function initElement() {
  gameStart = document.querySelector('#gameStart');
  gameSpeed = document.querySelector('#gameSpeed');
  gameArea = document.querySelector('#gameArea');

  gameAreaContext = gameArea.getContext('2d');
  gameAreaWidth = 400;
  gameAreaHeight = 600;
  cellSize = 20;
  gameArea.width = gameAreaWidth;
  gameArea.height = gameAreaHeight;
}

// Створення їжі для змії з випадковими координатами
function createFood() {
  snakeFood = {
    x: Math.round(Math.random() * (gameAreaWidth - cellSize) / cellSize), 
    y: Math.round(Math.random() * (gameAreaHeight - cellSize) / cellSize),
    
    // генерують випадкові числа в діапазоні від 0 до ширини та висоти гри в пікселях відповідно,
    // за винятком розміру однієї клітинки (cellSize), щоб їжа не випала за межі гри.
  };
}

// Перевірка, чи змія з'їла саму себе
function control(x, y, array) {
  for (var i = 0, length = array.length; i < length; i++) {
    if (array[i].x == x && array[i].y == y) return true;
  }
  return false;
}

// Виведення рахунку гравця на екран
function writeScore() {
  gameAreaContext.font = '50px sans-serif';
  gameAreaContext.fillStyle = '#FF0000';
  gameAreaContext.fillText('Score: ' + playerScore, (gameAreaWidth / 2) - 100, gameAreaHeight / 2);
}

// Малювання клітинки на канві
function createSquare(x, y) {
  gameAreaContext.fillStyle = '#000000';
  gameAreaContext.fillRect(x * cellSize, y * cellSize, cellSize, cellSize); 
}

// Оновлення гри: рух змії, перевірка зіштовхнення, з'їдання їжі та інші операції
function createGameArea() {
  var snakeX = snake[0].x;
  var snakeY = snake[0].y;

  // Очистка області гри
  gameAreaContext.fillStyle = '#FFFFFF';
  gameAreaContext.fillRect(0, 0, gameAreaWidth, gameAreaHeight);

  // Малювання межі області гри
  gameAreaContext.strokeStyle = '#000000';
  gameAreaContext.strokeRect(0, 0, gameAreaWidth, gameAreaHeight);

  // Зміна координат для руху змії в залежності від напрямку
  switch (snakeDirection) {
    case 'right':
      snakeX++;
      break;
    case 'left':
      snakeX--;
      break;
    case 'down':
      snakeY++;
      break;
    case 'up':
      snakeY--;
      break;
  }
  
  // Перевірка на зіштовхнення з межами або самою собою
  if ((snakeX == -1) || (snakeX == gameAreaWidth / cellSize) || (snakeY == -1) || (snakeY == gameAreaHeight / cellSize) || control(snakeX, snakeY, snake)) {
    // Виведення рахунку та очищення таймеру гри
    writeScore();
    clearInterval(timer);
    gameStart.disabled = false;
    return;
  }

  // Перевірка, чи змія з'їла їжу
  if (snakeX == snakeFood.x && snakeY == snakeFood.y) { // з'їла = створення нової голови
    var newHead = { x: snakeX, y: snakeY };
    playerScore += speedSize;
    createFood(); 
  } else { //не з'їла = підміна хвоста на голову
    var newHead = snake.pop(); // видалення останнього елементу і його повернення (тобто сам рух)
    newHead.x = snakeX;
    newHead.y = snakeY; 
  }

  // Додавання нової голови змії та малювання всієї змії на канві
  snake.unshift(newHead); // додавання елементу на початок масиву

  for (var i = 0, length = snake.length; i < length; i++) { // графічне віжображення нових координатів
    createSquare(snake[i].x, snake[i].y);
  }

  // Малювання їжі на канві
  createSquare(snakeFood.x, snakeFood.y);
}

// Початок гри: ініціалізація змійки та початкової їжі
function startGame() {
  snake = [];
  snake.push({ x: 0, y: cellSize }); // додає початковий сегмент змії (в кінець масиву)

  createFood();

  clearInterval(timer); // очищає попередній інтервал гри, якщо він вже був встановлений раніше, щоб уникнути конфліктів з попередньою грою.
  timer = setInterval(createGameArea, 500 / speedSize); // дія і через скільки мілесекунд
}

// Обробник кліку на кнопку "Start"
function onStartGame() {
  this.disabled = true;

  playerScore = 0;
  snakeDirection = 'right';
  speedSize = parseInt(gameSpeed.value);

  // Обмеження швидкості в межах від 1 до 9
  if (speedSize > 9) {
    speedSize = 9;
  } else if (speedSize < 0) {
    speedSize = 1;
  }

  startGame();
}

// Зміна напрямку змії за допомогою клавіш стрілок
function changeDirection(inputKey) {
  var keys = inputKey.which; // отримання коду клавіші
  if ((keys == '40' || keys == '83') && snakeDirection != 'up') snakeDirection = 'down'; // 40 - ArrowDown, 83 - S
  else if ((keys == '39' || keys == '68') && snakeDirection != 'left') snakeDirection = 'right'; // 39 - ArrowRight, 68 - D
  else if ((keys == '38' || keys == '87') && snakeDirection != 'down') snakeDirection = 'up'; // 38 - ArrowUp, 87 - W
  else if ((keys == '37' || keys == '65') && snakeDirection != 'right') snakeDirection = 'left'; // 37 - ArrowLeft, 65 - A
}


// Ініціалізація подій
function initEvent() {
  gameStart.addEventListener('click', onStartGame);
  window.addEventListener('keydown', changeDirection);
}

// Ініціалізація гри при завантаженні веб-сторінки
function init() {
  initElement();
  initEvent();
}

window.addEventListener('DOMContentLoaded', init);
